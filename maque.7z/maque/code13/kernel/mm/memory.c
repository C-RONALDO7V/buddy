#include <xtos.h>
/*
#include <stddef.h>
#include <stdint.h>
#include <assert.h>
*/
// Define macros related to the Control and Status Register (CSR)
#define CSR_BADV 0x7              // Store the address related to the most recent virtual address exception
#define CSR_PWCL 0x1c             // Page Table Width and Structure Control Register
#define CSR_DMW0 0x180            // Direct Mapping Window 0
#define CSR_DMW3 0x183            // Direct Mapping Window 3
#define CSR_DMW0_PLV0 (1UL << 0)  // Configure the direct mapping window to a specific privilege level

// Define memory-related macros
#define MEMORY_SIZE 0x8000000                 // Total memory size (128MB)
#define NR_PAGE (MEMORY_SIZE >> 12)           // Number of pages (memory size / page size, page size is 4KB)
#define MAX_ORDER 15                          // The largest block in the buddy system is 2^MAX_ORDER pages
#define KERNEL_START_PAGE (0x200000UL >> 12)  // Kernel start page number (2MB)
#define KERNEL_END_PAGE (0x300000UL >> 12)    // Kernel end page number (3MB)
#define ENTRY_SIZE 8                          // Page table entry size (bytes)
#define PWCL_PTBASE 12                        // Page table base address offset
#define PWCL_PTWIDTH 9                        // Page table width
#define PWCL_PDBASE 21                        // Page directory base address offset
#define PWCL_PDWIDTH 9                        // Page directory width
#define PWCL_EWIDTH 0                         // Entry width
#define ENTRYS 512                            // Maximum number of entries in a page table or page directory
#define USED_STATE_SIZE ((NR_PAGE >> 3) + 1)

#define PAGE_SHIFT 12                         // Corresponds to 4 KB page size

/*
struct buddy {
    size_t size;
    uintptr_t* longest;
    size_t longest_num_page;
    size_t total_num_page;
    size_t free_size;
    struct Page* begin_page;
};
struct buddy mem_buddy[MAX_NUM_BUDDY_ZONE];
int num_buddy_zone = 0;

// Initialize the memory map for the buddy system
static void
buddy_init_memmap(struct Page* base, size_t n) {
    printk("n: %d\n", n);
    struct buddy* buddy = &mem_buddy[num_buddy_zone++];
    size_t v_size = next_power_of_2(n);
    size_t excess = v_size - n;
    size_t v_alloced_size = next_power_of_2(excess);
    buddy->size = v_size;
    buddy->free_size = v_size - v_alloced_size;
    buddy->longest = page2kva(base);
    buddy->begin_page =
        pa2page(PADDR(ROUNDUP(buddy->longest + 2 * v_size * sizeof(uintptr_t), PGSIZE)));
    buddy->longest_num_page = buddy->begin_page - base;
    buddy->total_num_page = n - buddy->longest_num_page;
    size_t node_size = buddy->size * 2;
    for (int i = 0; i < 2 * buddy->size - 1; i++) {
        if (IS_POWER_OF_2(i + 1)) {
            node_size /= 2;
        }
        buddy->longest[i] = node_size;
    }
    int index = 0;
    while (1) {
        if (buddy->longest[index] == v_alloced_size) {
            buddy->longest[index] = 0;
            break;
        }
        index = RIGHT_LEAF(index);
    }
    while (index) {
        index = PARENT(index);
        buddy->longest[index] =
            MAX(buddy->longest[LEFT_LEAF(index)], buddy->longest[RIGHT_LEAF(index)]);
    }
    struct Page* p = buddy->begin_page;
    for (; p != base + buddy->free_size; p++) {
        assert(PageReserved(p));
        p->flags = p->property = 0;
        set_page_ref(p, 0);
    }
}

// Allocate pages in the buddy system
static struct Page*
buddy_alloc_pages(size_t n) {
    assert(n > 0);
    if (!IS_POWER_OF_2(n))
        n = next_power_of_2(n);
    size_t index = 0;
    size_t node_size;
    size_t offset = 0;
    struct buddy* buddy = NULL;
    for (int i = 0; i < num_buddy_zone; i++) {
        if (mem_buddy[i].longest[index] >= n) {
            buddy = &mem_buddy[i];
            break;
        }
    }
    if (!buddy) {
        return NULL;
    }
    for (node_size = buddy->size; node_size != n; node_size /= 2) {
        if (buddy->longest[LEFT_LEAF(index)] >= n)
            index = LEFT_LEAF(index);
        else
            index = RIGHT_LEAF(index);
    }
    buddy->longest[index] = 0;
    offset = (index + 1) * node_size - buddy->size;
    while (index) {
        index = PARENT(index);
        buddy->longest[index] = MAX
        (buddy->longest[LEFT_LEAF(index)], buddy->longest[RIGHT_LEAF(index)]);
    }
    buddy->free_size -= n;
    return buddy->begin_page + offset;
}

// Free pages in the buddy system
static void
buddy_free_pages(struct Page* base, size_t n) {
    struct buddy* buddy = NULL;
    for (int i = 0; i < num_buddy_zone; i++) {
        struct buddy* t = &mem_buddy[i];
        if (base >= t->begin_page && base < t->begin_page + t->size) {
            buddy = t;
        }
    }
    if (!buddy) return;
    unsigned node_size, index = 0;
    unsigned left_longest, right_longest;
    unsigned offset = base - buddy->begin_page;
    assert(offset >= 0 && offset < buddy->size);
    node_size = 1;
    index = offset + buddy->size - 1;
    for (; buddy->longest[index]; index = PARENT(index)) {
        node_size *= 2;
        if (index == 0)
            return;
    }
    buddy->longest[index] = node_size;
    buddy->free_size += node_size;
    while (index) {
        index = PARENT(index);
        node_size *= 2;
        left_longest = buddy->longest[LEFT_LEAF(index)];
        right_longest = buddy->longest[RIGHT_LEAF(index)];
        if (left_longest + right_longest == node_size)
            buddy->longest[index] = node_size;
        else
            buddy->longest[index] = MAX(left_longest, right_longest);
    }
}

// Calculate the next power of 2 for a given size
static size_t next_power_of_2(size_t size) {
    size |= size >> 1;
    size |= size >> 2;
    size |= size >> 4;
    size |= size >> 8;
    size |= size >> 16;
    return size + 1;
}
*/
// External variables: current process and shared memory table
extern struct process* current;
extern struct shmem shmem_table[NR_SHMEM];

struct buddy_node_t {
    union {
        struct buddy_node_t* prev_node;        // Previous node
        unsigned long ref_count;              // Reference count
    };
    union {
        struct buddy_node_t* next_node;        // Next node
        unsigned long order;                  // Memory block order
    };
} area[NR_PAGE];

struct buddy_sys_t {
    struct buddy_node_t head[MAX_ORDER + 1];
    unsigned long used[USED_STATE_SIZE];
} buddy_sys;


// Initialize the buddy system
void buddy_init() {
    for (unsigned long i = 0; i < MAX_ORDER; ++i)
        buddy_sys.head[i].next_node = buddy_sys.head[i].prev_node = 0;
    buddy_sys.head[MAX_ORDER].next_node = &area[0];
    area[0].prev_node = &buddy_sys.head[MAX_ORDER];
}

// Set the used state of a buddy node
void set_use_state(struct buddy_node_t* which) {
    unsigned long pos = which - area;
    buddy_sys.used[pos >> 3] |= 1LU << (pos & 7);
}

// Reset the used state of a buddy node
void reset_use_state(struct buddy_node_t* which) {
    unsigned long pos = which - area;
    buddy_sys.used[pos >> 3] &= ~(1LU << (pos & 7));
}

// Get the used state of a buddy node
int get_use_state(struct buddy_node_t* which) {
    unsigned long pos = which - area;
    return (buddy_sys.used[pos >> 3] & (1LU << (pos & 7))) ? 1 : 0;
}

// Get the buddy of a given buddy node
struct buddy_node_t* get_buddy(struct buddy_node_t* which, unsigned long order) {
    return area + ((which - area) ^ (1 << order));
}

// Allocate buddy pages of a specific order
unsigned long get_buddy_pages(unsigned long order) {
    unsigned long req_order = order;
    while (req_order <= MAX_ORDER) {
        if (buddy_sys.head[req_order].next_node) { // Successfully find an available memory block
            struct buddy_node_t* which = buddy_sys.head[req_order].next_node;
            // Remove from the free node list
            buddy_sys.head[req_order].next_node = which->next_node;
            if (which->next_node)
                which->next_node->prev_node = &buddy_sys.head[req_order];
            // Split to the desired order of memory block
            while (req_order != order) {
                --req_order;
                struct buddy_node_t* buddyy = get_buddy(which, req_order);
                // Insert the buddy node into the free memory list
                buddyy->next_node = buddy_sys.head[req_order].next_node;
                if (buddyy->next_node)
                    buddyy->next_node->prev_node = buddyy;
                buddyy->prev_node = &buddy_sys.head[req_order];
                buddy_sys.head[req_order].next_node = buddyy;
            }
            which->order = order;
            which->ref_count = 1;
            set_use_state(which);
            unsigned long page = ((which - area) << 12) | DMW_MASK;  // Calculate the physical address
            set_mem((char*)page, 0, PAGE_SIZE << order);
            return page;
        }
        ++req_order;
    }
    panic("panic: out of memory!\n");  // Trigger out-of-memory error if no free pages
    return 0;
}

// Free buddy pages
void free_buddy_pages(unsigned long page) {
    unsigned long id = (page & ~DMW_MASK) >> 12;
    struct buddy_node_t* which = area + id;
    if (!get_use_state(which)) {
        panic("panic: try to free illegal page!\n");  // Try to free unallocated or sub-block memory
        return;
    }
    which->ref_count -= 1;
    if (!which->ref_count) {
        reset_use_state(which);
        unsigned long order = which->order;
        struct buddy_node_t* buddy = get_buddy(which, order);
        while (!get_use_state(buddy)) {
            // Remove buddy from the free nodes
            buddy->prev_node->next_node = buddy->next_node;
            if (buddy->next_node) buddy->next_node->prev_node = buddy->prev_node;
            ++order; // Merge nodes
            if (order != MAX_ORDER) buddy = get_buddy(which, order);
            else break; // The largest node
        }
        // Insert the merged memory block into the free nodes
        which->next_node = buddy_sys.head[order].next_node;
        if (which->next_node)
            which->next_node->prev_node = which;
        which->prev_node = &buddy_sys.head[order];
        buddy_sys.head[order].next_node = which;
    }
}

// Share buddy pages (increase reference count)
void share_buddy_pages(unsigned long page) {
    unsigned long id = (page & ~DMW_MASK) >> 12;
    struct buddy_node_t* which = area + id;
    if (!get_use_state(which)) {
        panic("panic: try to share illegal page!\n");  // Try to share unallocated or sub-block memory
    }
    which->ref_count += 1;
}

// Check if a buddy page is shared
int is_share_buddy_pages(unsigned long page) {
    unsigned long id = (page & ~DMW_MASK) >> 12;
    struct buddy_node_t* which = area + id;
    return get_use_state(which) && which->ref_count > 1 ? 1 : 0;
}


// Allocate a new physical page
unsigned long get_page() {
    return get_buddy_pages(0);
}


// Allocate large memory
unsigned long get_large_memory(unsigned long sizes) {
    unsigned long order = 0;
    while ((1UL << (PAGE_SHIFT + order)) < sizes) {
        ++order;
    }
    if (order > MAX_ORDER) {
        panic("panic: requested sizes exceeds maximum manageable memory!\n");
    }
    return get_buddy_pages(order);
}

// Free a physical page
void free_page(unsigned long page) {
    free_buddy_pages(page);
}

// Increase the share count of a physical page
void share_page(unsigned long page) {
    share_buddy_pages(page);
}

// Check if a page is a shared page
int is_share_page(unsigned long page) {
    return is_share_buddy_pages(page);
}

// Get the pointer to the page table entry for a virtual address in a process
unsigned long* get_pte(struct process* p, unsigned long u_vaddr) {
    unsigned long pd, pt;
    unsigned long* pde, * pte;

    pd = p->page_directory;                                               // Get the page directory address of the process
    pde = (unsigned long*)(pd + ((u_vaddr >> 21) & 0x1ff) * ENTRY_SIZE);  // Calculate the page directory entry address
    if (*pde)                                                             // If the page directory entry exists
        pt = *pde | DMW_MASK;                                             // Get the page table address
    else {                                                                // If the page directory entry does not exist
        pt = get_page();                                                  // Allocate a new page as the page table
        *pde = pt & ~DMW_MASK;                                            // Update the page directory entry
    }
    pte = (unsigned long*)(pt + ((u_vaddr >> 12) & 0x1ff) * ENTRY_SIZE);  // Calculate the page table entry address
    return pte;                                                           // Return the page table entry pointer
}

// Map a physical page to a virtual address
void put_page(struct process* p, unsigned long u_vaddr, unsigned long k_vaddr, unsigned long attr) {
    unsigned long* pte;

    pte = get_pte(p, u_vaddr);            // Get the page table entry pointer
    if (*pte)                             // If the virtual address is already mapped
        panic("panic: try to remap!\n");  // Report an error
    *pte = (k_vaddr & ~DMW_MASK) | attr;  // Set the page table entry
    invalidate();                         // Flush the page table cache
}

// Free all page tables of a process
void free_page_table(struct process* p) {
    unsigned long pd, pt;
    unsigned long* pde, * pte;
    unsigned long page;

    pd = p->page_directory;  // Get the page directory address
    pde = (unsigned long*)pd;
    for (int i = 0; i < ENTRYS; i++, pde++) {  // Traverse the page directory
        if (*pde == 0) {
            continue;          // Skip the unused page directory entries
        }
        pt = *pde | DMW_MASK;  // Get the page table address
        pte = (unsigned long*)pt;
        for (int j = 0; j < ENTRYS; j++, pte++) {  // Traverse the page table
            if (*pte == 0) {
                continue;                         // Skip the unused page table entries
            }
            page = (~0xfffUL & *pte) | DMW_MASK;  // Get the physical page address
            if (is_share_page(page) && (*pte & PTE_D)) {
                for (int i = 0; i < NR_SHMEM; i++) {
                    if (shmem_table[i].mem == page) {
                        shmem_table[i].count--;  // Update the share count
                        break;
                    }
                }
            }
            free_page(page);  // Free the physical page
            *pte = 0;         // Clear the page table entry
        }
        free_page(*pde | DMW_MASK);  // Free the page table
        *pde = 0;                    // Clear the page directory entry
    }
}

// Copy the page table from one process to another
void copy_page_table(struct process* from, struct process* to) {
    unsigned long from_pd, to_pd, from_pt, to_pt;
    unsigned long* from_pde, * to_pde, * from_pte, * to_pte;
    unsigned long page;
    int i, j;

    // Get the page directory addresses of the source and target processes
    from_pd = from->page_directory;
    from_pde = (unsigned long*)from_pd;
    to_pd = to->page_directory;
    to_pde = (unsigned long*)to_pd;

    // Traverse the source page directory
    for (i = 0; i < ENTRYS; i++, from_pde++, to_pde++) {
        if (*from_pde == 0) {  // Skip the unused page directory entries
            continue;
        }

        // Get the source page table address
        from_pt = *from_pde | DMW_MASK;
        from_pte = (unsigned long*)from_pt;

        // Allocate a new page as the page table for the target
        to_pt = get_page();
        to_pte = (unsigned long*)to_pt;

        // Update the target page directory entry
        *to_pde = to_pt & ~DMW_MASK;

        // Traverse the source page table
        for (j = 0; j < ENTRYS; j++, from_pte++, to_pte++) {
            if (*from_pte == 0) {  // Skip the unused page table entries
                continue;
            }

            // Get the physical page address
            page = (~0xfffUL & *from_pte) | DMW_MASK;

            // If it is a shared page and a dirty page, skip copying
            if (is_share_page(page) && (*from_pte & PTE_D)) {
                continue;
            }

            // Increase the share count
            share_page(page);

            // Clear the dirty bit of the source page
            *from_pte &= ~PTE_D;

            // Copy the source page table entry to the target page table
            *to_pte = *from_pte;
        }
    }

    // Flush the page table cache
    invalidate();
}

// Write protection exception handler function
void do_wp_page() {
    unsigned long* pte;
    unsigned long u_vaddr;
    unsigned long old_page, new_page;

    u_vaddr = read_csr_64(CSR_BADV);        // Read the virtual address that triggered the exception
    pte = get_pte(current, u_vaddr);        // Get the page table entry corresponding to this address
    old_page = (~0xfff & *pte) | DMW_MASK;  // Get the corresponding physical page address

    // If the physical page is a shared page
    if (is_share_page(old_page)) {
        new_page = get_page();                                    // Allocate a new physical page
        *pte = (new_page & ~DMW_MASK) | PTE_PLV | PTE_D | PTE_V;  // Update the page table to map the new page
        copy_mem((char*)new_page, (char*)old_page, PAGE_SIZE);    // Copy the data from the old page to the new page
        free_page(old_page);                                      // Free the old physical page
    }
    else {
        *pte |= PTE_D;  // If it is not a shared page, just remove the write protection
    }

    invalidate();  // Flush the page table cache
}

// Page fault exception handler function
void do_no_page() {
    unsigned long page;
    unsigned long u_vaddr;

    u_vaddr = read_csr_64(CSR_BADV);  // Get the virtual address that triggered the exception
    u_vaddr &= ~0xfffUL;              // Align to the page boundary
    page = get_page();                // Allocate a new physical page

    // If the page fault address belongs to the executable segment
    if (u_vaddr < current->exe_end) {
        get_exe_page(u_vaddr, page);  // Load the code segment to the physical page
    }

    // Update the page table to establish the mapping between virtual and physical addresses
    put_page(current, u_vaddr, page, PTE_PLV | PTE_D | PTE_V);
}

// Memory initialization function
void mem_init() {
    buddy_init();
    // Configure the direct mapping window
    write_csr_64(CSR_DMW0_PLV0 | DMW_MASK, CSR_DMW0);
    write_csr_64(0, CSR_DMW3);  // Disable the unnecessary window
    write_csr_64((PWCL_EWIDTH << 30) | (PWCL_PDWIDTH << 15) |
        (PWCL_PDBASE << 10) | (PWCL_PTWIDTH << 5) |
        (PWCL_PTBASE << 0),
        CSR_PWCL);
    invalidate();  // Flush the page table cache
    shmem_init();  // Initialize the shared memory table
}
