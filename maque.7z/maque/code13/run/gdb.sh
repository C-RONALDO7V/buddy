#!/bin/bash

../../cross-tool/loongarch64-unknown-linux-gnu-gdb -x ./gdb_cmd kernel
